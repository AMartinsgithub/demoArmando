package br.com.testearmando.demoArmando;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableAutoConfiguration
@EnableJpaRepositories({"br.com.testearmando.ws.repository"})
@ComponentScan({"br.com.testearmando.ws.controller","br.com.testearmando.ws.repository","br.com.testearmando.ws.model"})
@EntityScan({"br.com.testearmando.ws.model"})
public class DemoArmandoApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(DemoArmandoApplication.class, args);
	}
	
}



//@EnableJpaRepositories(basePackages = "br.com.testearmando.ws.repository", repositoryImplementationPostfix = "Impl", repositoryFactoryBeanClass = AuthRepositoryFactoryBean.class)