package br.com.testearmando.ws.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.testearmando.ws.model.Cliente;
import br.com.testearmando.ws.repository.ClienteRepository;


/* @RestController - Objeto de controle do Spring (Como se fosse um servlet - quem recebe as requisições) 
 * Torna a objeto capaz de receber e responder as requisições https.
 * controlador das requisições.
 */

@RestController
@RequestMapping("/clientes")

public class clientecontroller {
	

	// Métodos de Negocios
	@Autowired
	ClienteRepository clienteRepository;
	
	Map<Integer, Cliente> clientes;
	Integer controlador_id = 0; 

	// Simulação de um banco de clientes.
	private Cliente armazenarCliente(Cliente cliente) {
		if (clientes.isEmpty()) clientes = new HashMap<Integer, Cliente>();
		cliente.setId(controlador_id++);
		cliente.setNome(cliente.getNome());
		clientes.put(cliente.getId(), cliente);
		return cliente;
	}
	

	// EndPoints
	@RequestMapping(method=RequestMethod.GET, value="/buscar/{nome}")
	public List<Cliente> buscarCliente(@PathVariable("nome") String cliente) {
		//System.out.println("Chamou o método do buscar do clientes");
		List<Cliente> list = Arrays.asList(clienteRepository.findByNome(cliente));
		return list; 
	}


	// EndPoints
	@GetMapping
	public List<Cliente> buscar() {
		//System.out.println("Chamou o método do buscar do clientes");
		List<Cliente> list = clienteRepository.findAll();
		return list; 
	}
	
	
	/* @RequestMapping = Mapeamento para identificar o recurso que será chamado pelo browser. 
	 *  method=RequestMethod = Indica qual o verbo http que vai responder essa requisição.
	 * 	RequestMethod.GET    - Recebe uma chamada.
	 *  RequestMethod.POST   - postar o result de uma chamada.
	 *  RequestMethod.DELETE - 
	 *  entre outros...
	 *  
	 * value = Indica o mapeamento da requisição, ou seja, sempre que tiver uma chamada com /clientes 
	 * esse método é quem irá responder. 
	 * 
	 * consumes = Indica como será o consumo da requisição GET. Como a informação vai chegar, qual o padrão. Nesse caso vamos informar que será uma string no formato JSON.
	 * Exemplo do Json
	 * {
	 * 	id = "";
	 *  nome = "";
	 * }
	 * 
	 * @RequestBody = Indica para o Spring deve jogar o JSON dentro do objeto Cliente, ou seja, o objeto cliente irá receber o valor enviado no JSON. 
	 * 
	 */
	//@RequestMapping(method=RequestMethod.POST, value="/cadastrar", consumes=MediaType.APPLICATION_JSON_VALUE)
	@PostMapping("/cadastrar")
	public String cadastrarCliente(@RequestBody Cliente cliente) {
		System.out.println("Chamou o método do buscar do clientes");
		//this.armazenarCliente(cliente);
		clienteRepository.save(cliente);
		return "ok";
	}
	
	
}
